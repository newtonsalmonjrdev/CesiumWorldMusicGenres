'use strict';

/**
 * 탭
 * @param {string} containerId 탭 컨테이너 ID명
 * @param {string} btnSelector 컨테이너 하위의 탭 버튼 선택자
 */
function setTab(containerId, btnSelector) {
  const tabContainer = document.getElementById(containerId);
  const btnTab       = tabContainer.querySelectorAll(btnSelector);
  const activeClass  = 'active';

  const removeActiveClass = target => target.classList.remove(activeClass);
  const addActiveClass    = target => target.classList.add(activeClass);

  function resetActiveTab() {
    const tabItem     = tabContainer.querySelectorAll('.tab-item');
    const tabContents = tabContainer.querySelectorAll('.tab-contents');

    tabItem.forEach(item => removeActiveClass(item));
    tabContents.forEach(content => removeActiveClass(content));
  }

  function setActiveTab(btn) {
    const tabTarget      = btn.dataset.tabTarget;
    const targetItem     = btn.closest('.tab-item');
    const targetContents = tabContainer.querySelector(`[data-tab-id="${tabTarget}"]`);

    addActiveClass(targetItem);
    addActiveClass(targetContents);
  }

  function clickHandler(e) {
    resetActiveTab();
    setActiveTab(this);
  }

  btnTab.forEach(btn => btn.addEventListener('click', clickHandler));
}

const tabContainerId = 'tabContainer';
const tabBtnSelector = '.btn-tab';

setTab(tabContainerId, tabBtnSelector);