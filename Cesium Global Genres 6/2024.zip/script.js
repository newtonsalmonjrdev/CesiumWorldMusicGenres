Cesium.Ion.defaultAccessToken =
  "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJqdGkiOiJjZTA0MTg3NS05MDI3LTRkODgtOWY4MC0wN2FhZmI5MmIwNDciLCJpZCI6MTA1OTM2LCJpYXQiOjE2NjczMzc5NjV9.XYrEYpTnMof8gTJYhXaQmIu3Pj2CAcnvE2fB0DxYcVU";

const { BoundingSphere, BoundingSphereState, Cartesian3, Color, Viewer } =
  window.Cesium;
//Imagery Provider
const imageryProvider = new Cesium.ArcGisMapServerImageryProvider({
  // url: "https://services.arcgisonline  .com/ArcGIS/rest/services/World_Imagery/MapServer",
  url: "https://services.arcgisonline.com/arcgis/rest/services/NatGeo_World_Map/MapServer",
});

const viewer = new Cesium.Viewer("cesiumContainer", {
  selectionIndicator: false,
  infoBox: false,
  imageryProvider: imageryProvider,
});

const scene = viewer.scene;
const camera = viewer.camera.position;
let camPos = viewer.camera.positionCartographic;
let latitude;
let longitude;
let windowPosition = "";
let entities = "";
let geoJSONDataList = "";
let objectDetected = false;
let ObjDetected_Long;
let ObjDetected_Lat;
const cssCircleOverlayX = viewer.container.clientWidth;
const cssCircleOverlayY = viewer.container.clientHeight;
const minimumzoomHeight = 2500000;
const maximumzoomHeight = 7000000;
let promise1 = [];

// window.onerror = stoperror;

//Disabling timeline and animation widgets
viewer.animation.container.style.visibility = "hidden";
viewer.timeline.container.style.visibility = "hidden";

viewer.forceResize();

circleX = viewer.container.clientWidth;
circleY = viewer.container.clientHeight;

//Circle animation when centering on point
const domspinningcircle = document.getElementById("spinningcircle");
const domcesiumContainer = document.getElementById("cesiumContainer");

// Function to make the container transparent
const makeTransparent = () => domspinningcircle.classList.add("transparent");

var handlerScreenCircle = new Cesium.ScreenSpaceEventHandler(
  viewer.scene.canvas
);

// Handle mousedown event
handlerScreenCircle.setInputAction(function () {
  domspinningcircle.classList.remove("transparent"); // Make container opaque when dragging starts
}, Cesium.ScreenSpaceEventType.LEFT_DOWN); // LEFT_DOWN is equivalent to mousedown

// Handle mouseup event
handlerScreenCircle.setInputAction(function () {
  domspinningcircle.classList.add("transparent"); // Make container transparent when mouse is released
}, Cesium.ScreenSpaceEventType.LEFT_UP); // LEFT_UP is equivalent to mouseup

setTimeout(makeTransparent, 6000); // Adjust the time as needed

// Clicking on Explore button
let isFirstClick = true;
// function exploreButtonClick()
document.querySelectorAll(".explorecontent-style").forEach(function (element) {
  element.style.display = "contents";
});

document.getElementById("exploreButton").addEventListener("click", function () {
  const alreadyActive = this.classList.contains("active");

  document.querySelectorAll(".button-toggle").forEach(function (element) {
    element.classList.remove("active");
  });
  document.querySelectorAll(".content").forEach(function (element) {
    element.classList.remove("active");
  });

  // document.getElementById("exploreContent").classList.add("active");

  if (alreadyActive) {
    // If 'searchButton' is not already active, add 'active' class to it and toggle all targets

    this.classList.remove("active");
    document
      .querySelectorAll(".explorecontent-style")
      .forEach(function (element) {
        element.style.display = "none";
      });
    // document.getElementById("exploreContent").classList.remove("active");
  } else if (isFirstClick) {
    document
      .querySelectorAll(".explorecontent-style")
      .forEach(function (element) {
        element.style.display = "none";
        isFirstClick = false;
      });
  } else {
    // Remove 'active' class from 'exploreButton'
    this.classList.add("active");
    document
      .querySelectorAll(".explorecontent-style")
      .forEach(function (element) {
        element.style.display = "contents";
      });
    document.getElementById("exploreContent").classList.add("active");
    // this.classList.remove("active");
    // document.getElementById("exploreContent").classList.remove("active");
  }
});

// exploreButtonClick();

//Clicking on Favorites tab button
// function favoritiesButtonClick() {
//   document
//     .getElementById("favoritesButton")
//     .addEventListener("click", function () {
//       const alreadyActive = this.classList.contains("active");

//       document.querySelectorAll(".button-toggle").forEach(function (element) {
//         element.classList.remove("active");
//       });
//       document.querySelectorAll(".content").forEach(function (element) {
//         element.classList.remove("active");
//       });

//       this.classList.remove("active");
//       document
//         .querySelectorAll(".explorecontent-style")
//         .forEach(function (element) {
//           element.style.display = "none";
//         });
//       if (alreadyActive) {
//         // Remove 'active' class from 'searchButton'
//         this.classList.remove("active");
//         document.getElementById("favoritesContent").classList.remove("active");
//       } else {
//         // If 'searchButton' is not already active, add 'active' class to it and toggle all targets
//         this.classList.add("active");
//         document.getElementById("favoritesContent").classList.add("active");
//       }
//     });
// }

// favoritiesButtonClick();

//Clicking on Playlist button
function playlistButtonClick() {
  document
    .getElementById("playlistsButton")
    .addEventListener("click", function () {
      const alreadyActive = this.classList.contains("active");

      document.querySelectorAll(".button-toggle").forEach(function (element) {
        element.classList.remove("active");
      });
      document.querySelectorAll(".content").forEach(function (element) {
        element.classList.remove("active");
      });

      this.classList.remove("active");
      document
        .querySelectorAll(".explorecontent-style")
        .forEach(function (element) {
          element.style.display = "none";
        });

      if (alreadyActive) {
        // Remove 'active' class from 'searchButton'
        this.classList.remove("active");
        document.getElementById("playlistsContent").classList.remove("active");
      } else {
        // If 'searchButton' is not already active, add 'active' class to it and toggle all targets
        this.classList.add("active");
        document.getElementById("playlistsContent").classList.add("active");
      }
    });
}
playlistButtonClick();

//Clicking on Search button
function searchButtonClick() {
  document
    .getElementById("searchButton")
    .addEventListener("click", function () {
      const alreadyActive = this.classList.contains("active");

      document.querySelectorAll(".button-toggle").forEach(function (element) {
        element.classList.remove("active");
      });
      document.querySelectorAll(".content").forEach(function (element) {
        element.classList.remove("active");
      });

      this.classList.remove("active");
      document
        .querySelectorAll(".explorecontent-style")
        .forEach(function (element) {
          element.style.display = "none";
        });

      if (alreadyActive) {
        // Remove 'active' class from 'searchButton'
        this.classList.remove("active");
        document.getElementById("searchContent").classList.remove("active");
      } else {
        // If 'searchButton' is not already active, add 'active' class to it and toggle all targets
        this.classList.add("active");
        document.getElementById("searchContent").classList.add("active");
      }
    });
}

searchButtonClick();

//Clicking on Settings button
function settingsButtonClick() {
  document
    .getElementById("settingsButton")
    .addEventListener("click", function () {
      const alreadyActive = this.classList.contains("active");

      document.querySelectorAll(".button-toggle").forEach(function (element) {
        element.classList.remove("active");
      });
      document.querySelectorAll(".content").forEach(function (element) {
        element.classList.remove("active");
      });

      this.classList.remove("active");
      document
        .querySelectorAll(".explorecontent-style")
        .forEach(function (element) {
          element.style.display = "none";
        });

      if (alreadyActive) {
        // Remove 'active' class from 'searchButton'
        this.classList.remove("active");
        document.getElementById("settingsContent").classList.remove("active");
      } else {
        // If 'searchButton' is not already active, add 'active' class to it and toggle all targets
        this.classList.add("active");
        document.getElementById("settingsContent").classList.add("active");
      }
    });
}

settingsButtonClick();

// var centerCircleElement = document.getElementById("centercircle");

// spinningcircle.style.position = "absolute";
// spinningcircle.style.left = "50%";
// spinningcircle.style.top = "50%";
// spinningcircle.style.transform = "translate(-50%, -50%)";

//Centering the HTML circle around the point position
// document.getElementById("centercircle").style.left = `${
//   cssCircleOverlayX - 65
// }px`;
// document.getElementById("centercircle").style.top = `${
//   cssCircleOverlayY - 65
// }px`;

//Setting the minimum and maximum zoom in level
viewer.scene.screenSpaceCameraController.minimumZoomDistance =
  minimumzoomHeight;
viewer.scene.screenSpaceCameraController.maximumZoomDistance =
  maximumzoomHeight;

//Loading Screen
const wait = (delay = 0) =>
  new Promise((resolve) => setTimeout(resolve, delay));

const setVisible = (elementOrSelector, visible) =>
  ((typeof elementOrSelector === "string"
    ? document.querySelector(elementOrSelector)
    : elementOrSelector
  ).style.display = visible ? "block" : "none");

setVisible(".page", false);
setVisible("#loading", true);

document.addEventListener("DOMContentLoaded", () =>
  wait(3000).then(() => {
    setVisible(".page", true);
    setVisible("#loading", false);
    setVisible(".datadisplay-inner", true);
  })
);

//Read quote lines
const url =
  "https://raw.githubusercontent.com/newtonsalmonjrdev/CesiumWorldMusicGenres/main/musicQuotes.json";
function getFromAPI(url, callback) {
  let obj;
  fetch(url)
    .then((res) => res.json())
    .then((data) => (obj = data))
    .then(() => callback(obj));
}
getFromAPI(url, generateQuotes);

function randomNumber(min, max) {
  return Math.floor(Math.random() * (max - min) + min);
}

async function generateQuotes(quotesObj) {
  const quoteNum = randomNumber(0, 42);
  const quoteDOM = quotesObj[quoteNum].quotes;
  const quoteDOMName = quotesObj[quoteNum].quoteName;

  // document.getElementById("quote").innerHTML = quoteDOM;
  // document.getElementById("quoteauthor").innerHTML = "~ " + quoteDOMName;
  // document.getElementById("quoteauthor").style.color = "darkblue";
}
// generateQuotes();

//Time stamp based on location
// Replace 'America/New_York' with the desired timezone
// const tzdData = geoJSONDataList.values[i - 1].properties.TZD;

// // Get the current time in the specified timezone
// const currentTime = moment.tz(tzdData).format("HH:mm");
// console.log(currentTime);

//Loading geoJSON files
function loadJSONPointsPolys() {
  const pointsJSON =
    "https://raw.githubusercontent.com/newtonsalmonjrdev/CesiumWorldMusicGenres/main/Sheet1_Layerexport_PointsP_9.geojson";
  promise1 = Cesium.GeoJsonDataSource.load(pointsJSON);

  promise1.then(function (dataSource1) {
    //Adding Polygon Points, 10 Miles Diameter
    entities = dataSource1.entities.values;
    geoJSONDataList = dataSource1.entities;
    viewer.dataSources.add(
      Cesium.GeoJsonDataSource.load(pointsJSON, {
        stroke: Cesium.Color.fromCssColorString("white"),
        fill: Cesium.Color.fromCssColorString("white").withAlpha(1),
        strokeWidth: 3,
      })
    );

    //Adding Polygons- to be converted into buffer ellipses, 100 Miles Diameter
    const polygonJSON =
      "https://raw.githubusercontent.com/newtonsalmonjrdev/CesiumWorldMusicGenres/main/buffer_1009_json.geojson";
    const promise2 = Cesium.GeoJsonDataSource.load(polygonJSON);
    promise2.then(function (dataSource2) {
      viewer.dataSources.add(
        Cesium.GeoJsonDataSource.load(polygonJSON, {
          stroke: Cesium.Color.TRANSPARENT,
          fill: Cesium.Color.TRANSPARENT.withAlpha(0.01),
          strokeWidth: 3,
        })
      );
    });
  });
}

//Getting the Cartesian point of the center window position
function getPosition() {
  windowPosition = new Cesium.Cartesian2(
    viewer.container.clientWidth / 2,
    viewer.container.clientHeight / 2
  );

  // circleY = viewer.container.clientHeight;

  // console.log("should print");
  let pickRay = viewer.scene.camera.getPickRay(windowPosition);
  let pickPosition = viewer.scene.globe.pick(pickRay, viewer.scene);
  let pickPositionCartographic =
    viewer.scene.globe.ellipsoid.cartesianToCartographic(pickPosition);

  longitude = pickPositionCartographic.longitude * (180 / Math.PI);
  latitude = pickPositionCartographic.latitude * (180 / Math.PI);
}

// This is what's retrieving the cursor's current postion
const handler = new Cesium.ScreenSpaceEventHandler(scene.canvas);
let handlermove = handler.setInputAction(function (movement) {
  getPosition();
}, Cesium.ScreenSpaceEventType.MOUSE_MOVE);

function stoperror() {
  return true;
}
stoperror();
let switch1 = "0";
// This is retrieving the geoJSON info
function getGeoJSONProps() {
  let handler1 = new Cesium.ScreenSpaceEventHandler(scene.canvas);
  handler1.setInputAction(function () {
    const idlist = [...Array(72).keys()];
    pickedObjects = scene.pick(windowPosition);
    if (Cesium.defined(pickedObjects)) {
      for (let i = 0; i < idlist.length; ++i) {
        if (pickedObjects.id.id === i) {
          //Getting Lat and Long data for fly-to-center function
          objectDetected = true;
          ObjDetected_Long = geoJSONDataList.values[i - 1].properties.Longitude;
          ObjDetected_Lat = geoJSONDataList.values[i - 1].properties.Latitude;
          //Removing Welcome div
          const getWelcomeDiv = document.getElementById("welcomedivID");
          if (typeof getWelcomeDiv != "undefined" && getWelcomeDiv != null) {
            document.getElementById("welcomedivID").remove();
          }

          //Pushing data into the DOM

          //Artist Name
          if (geoJSONDataList.values[i - 1].properties.Artist_Name != "NA") {
            document.getElementById("artistname").innerHTML =
              geoJSONDataList.values[i - 1].properties.Artist_Name;
            document.getElementById("artistname").style.color = "white";
          } else {
            document.getElementById("artistname").innerHTML = "";
          }
          //Band Group
          if (
            geoJSONDataList.values[i - 1].properties.Band_Group__if_any_ != "NA"
          ) {
            document.getElementById("bandgroup").innerHTML =
              geoJSONDataList.values[i - 1].properties.Band_Group__if_any_;
            document.getElementById("bandgroup").style.display = "none";
          } else {
            document.getElementById("bandgroup").innerHTML = "";
          }
          //Birth Year
          if (geoJSONDataList.values[i - 1].properties.Birth_Year != "NA") {
            document.getElementById("birthyear").innerHTML =
              geoJSONDataList.values[i - 1].properties.Birth_Year + "&nbsp —";
            document.getElementById("birthyear").style.display = "none";
          } else {
            document.getElementById("birthyear").innerHTML = "";
          }

          //Death Year
          if (geoJSONDataList.values[i - 1].properties.Death_Year != "NA") {
            document.getElementById("deathyear").innerHTML =
              geoJSONDataList.values[i - 1].properties.Death_Year;
            document.getElementById("deathyear").style.display = "none";
          } else {
            document.getElementById("deathyear").innerHTML = "Present";
          }

          // Country of Birth
          if (
            geoJSONDataList.values[i - 1].properties.Country_of_Birth != "NA"
          ) {
            document.getElementById("birthcountry").innerHTML =
              geoJSONDataList.values[i - 1].properties.Country_of_Birth;
            document.getElementById("birthcountry").style.color = "gold";
          } else {
            document.getElementById("birthcountry").innerHTML = "";
          }

          // Primary Genre
          if (geoJSONDataList.values[i - 1].properties.Primary_Genre != "NA") {
            document.getElementById("primarygen").innerHTML =
              geoJSONDataList.values[i - 1].properties.Primary_Genre + "&ensp;";
          } else {
            document.getElementById("primarygen").innerHTML = "";
          }

          // Secondary Genre
          if (
            geoJSONDataList.values[i - 1].properties.Secondary_Genre != "NA"
          ) {
            document.getElementById("secondgen").innerHTML =
              geoJSONDataList.values[i - 1].properties.Secondary_Genre +
              "&ensp;";
            document.getElementById("secondgen").style.display = "none";
          } else {
            document.getElementById("secondgen").innerHTML = "";
          }

          //Tertiary Genre
          if (geoJSONDataList.values[i - 1].properties.Tertiary_Genre != "NA") {
            document.getElementById("tertgen").innerHTML =
              geoJSONDataList.values[i - 1].properties.Tertiary_Genre;
            document.getElementById("tertgen").style.display = "none";
          } else {
            document.getElementById("tertgen").innerHTML = "";
          }

          //Wikipedia
          if (geoJSONDataList.values[i - 1].properties.Wikipedia_Link != "NA") {
            let wikiurl =
              geoJSONDataList.values[i - 1].properties.Wikipedia_Link;
            document.getElementById("wikilink").setAttribute("href", wikiurl);
            document.getElementById("wikilink").innerHTML = "Wikipedia";
            document.getElementById("wikilink").style.display = "none";
          } else {
            document.getElementById("wikilink").innerHTML = "";
          }

          //Youtube
          if (geoJSONDataList.values[i - 1].properties.Youtube != "NA") {
            let youtubeurl = geoJSONDataList.values[i - 1].properties.Youtube;
            document
              .getElementById("youtubelink")
              .setAttribute("href", youtubeurl);
            document.getElementById("youtubelink").innerHTML = "Youtube";
            document.getElementById("youtubelink").style.display = "none";
          } else {
            document.getElementById("youtubelink").innerHTML = "";
          }

          //City of Birth
          if (geoJSONDataList.values[i - 1].properties.City_of_Birth != "NA") {
            document.getElementById("birthcity").innerHTML =
              geoJSONDataList.values[i - 1].properties.City_of_Birth + ", ";
            document.getElementById("birthcity").style.color = "white";
          } else {
            document.getElementById("birthcity").innerHTML = "";
          }

          //Alias
          if (geoJSONDataList.values[i - 1].properties.Alias_Name != "NA") {
            document.getElementById("alias").innerHTML =
              "A.K.A. " + geoJSONDataList.values[i - 1].properties.Alias_Name;
            document.getElementById("alias").style.display = "none";
          } else {
            document.getElementById("alias").innerHTML = "";
            document.getElementById("alias").style.color = "purple";
          }

          if (geoJSONDataList.values[i - 1].properties.Spotify_Code != "NA") {
            // Spotify Playlist
            // document.getElementById("spotifyiframe").src =
            //   geoJSONDataList.values[i - 1].properties.SpotifySrc;

            const strSpotify =
              geoJSONDataList.values[i - 1].properties.SpotifySrc._value;
            const parts = strSpotify.split("/");

            // The artist ID should be the part right before the query parameters, assuming the URL structure remains constant
            const artistIDWithParams = parts[parts.length - 1];

            // Splitting by '?' to remove any query parameters
            const artistID = artistIDWithParams.split("?")[0];
            const artistURI = `spotify:artist:${artistID}`;

            window.artistURI = artistURI;
            console.log(artistURI);
            const elementToRemove = document.getElementById("embed-outer");

            elementToRemove.remove();
            console.log("YES!");

            const parentElement = document.getElementById("databoxid");
            console.log(parentElement);
            const newSpotifyOuterDiv = document.createElement("div");
            const newSpotifyInnerDiv = document.createElement("div");

            // Set IDs
            newSpotifyOuterDiv.id = "embed-outer";
            newSpotifyInnerDiv.id = "embed-iframe";

            // Set styles
            // newSpotifyOuterDiv.style.zIndex = "1001";
            // newSpotifyOuterDiv.style.color = "red";
            // Set class
            // newSpotifyOuterDiv.className = "spotifypl"; // Correct way to set a class

            // Append the inner div to the outer div
            newSpotifyOuterDiv.appendChild(newSpotifyInnerDiv);
            console.log(parentElement);
            // Append the outer div to the parent element
            parentElement.appendChild(newSpotifyOuterDiv);

            // Logging
            console.log(newSpotifyOuterDiv);
            console.log(newSpotifyInnerDiv);
            // console.log("create");
            // const parentElement = document.getElementById("data-box");

            // // Append the new element to the parent element

            // const newSpotifyOuterDiv = document.createElement("div");
            // const newSpotifyInnerDiv = document.createElement("div");
            // newSpotifyOuterDiv.id = "embed-outer";
            // newSpotifyInnerDiv.id = "embed-iframe";
            // newSpotifyOuterDiv.style.zIndex = "1001";
            // newSpotifyOuterDiv.style.color = "red";
            // parentElement.appendChild(newSpotifyOuterDiv);
            // parentElement.appendChild(newSpotifyInnerDiv);
            // // newSpotifyOuterDiv.class = "spotifypl";
            // console.log(newSpotifyOuterDiv);
            // console.log(newSpotifyInnerDiv);

            window.onSpotifyIframeApiReady = (IFrameAPI) => {
              // const embedIframe = document.getElementById("embed-iframe");
              const options = {
                width: "100%",
                height: "160",
                uri: artistURI, // Use artistURI that you've already prepared
              };

              IFrameAPI.createController(
                newSpotifyInnerDiv,
                options,
                (EmbedController) => {
                  // Immediately load the artist URI without waiting for a mouseup event
                  EmbedController.loadUri(artistURI);
                  EmbedController.play();
                }
              );
            };

            //See More Button Visibility
            const moreContent = document.getElementById("seeMoreBtn");
            if (
              moreContent.style.display === "block" ||
              moreContent.style.display === ""
            ) {
              moreContent.style.display = "block";
              moreContent.textContent = "See more";
              console.log("See more");
            } else {
              moreContent.style.display = "none";
              // moreContent.textContent = "See less";
              // console.log("See less");
            }
          } else {
            document.getElementById("spotifyiframe").src = "";
          }
        } else {
          continue;
        }
      }
      flyToOnClick();
    }
  }, Cesium.ScreenSpaceEventType.LEFT_UP);
}

//Showing and hiding information with 'See More' button
document.getElementById("seeMoreBtn").addEventListener("click", function () {
  const moreContent = document.getElementById("seeMoreBtn");
  const birthYearElement = document.getElementById("birthyear");
  const deathYearElement = document.getElementById("deathyear");
  const secondaryGenElement = document.getElementById("secondgen");
  const tertGenElement = document.getElementById("tertgen");
  const wikiLinkElement = document.getElementById("wikilink");
  const youtubeElement = document.getElementById("youtubelink");
  const aliasElement = document.getElementById("alias");

  if (moreContent.textContent === "See less") {
    moreContent.textContent = "See more";
    birthYearElement.style.display = "none";
    deathYearElement.style.display = "none";
    secondaryGenElement.style.display = "none";
    tertGenElement.style.display = "none";
    wikiLinkElement.style.display = "none";
    youtubeElement.style.display = "none";
    aliasElement.style.display = "none";
  } else if (moreContent.textContent === "See more") {
    moreContent.textContent = "See less";
    birthYearElement.style.display = "block";
    deathYearElement.style.display = "block";
    secondaryGenElement.style.display = "block";
    tertGenElement.style.display = "block";
    wikiLinkElement.style.display = "block";
    youtubeElement.style.display = "block";
    aliasElement.style.display = "block";
  }
});

loadJSONPointsPolys();
getGeoJSONProps();

function getCameraHeight() {
  var scene = viewer.scene;
  var cameraHeight = scene.camera.positionCartographic.height;
  return cameraHeight;
}

// Example usage

function flyToOnClick() {
  if (objectDetected) {
    // Get the camera height
    let cameraHeight = viewer.camera._positionCartographic.height;
    // Here position is a Cartesian3 of the camera destination
    const ObjDetectXY = Cesium.Cartesian3.fromDegrees(
      Number(ObjDetected_Long),
      Number(ObjDetected_Lat),
      1000000
    );
    let cartographicDesination = Cesium.Cartographic.fromCartesian(ObjDetectXY);

    // Override its height
    cartographicDesination.height = cameraHeight;
    // Set it back to a Cartesian3, then fly to this destination
    const ObjDetectXYZ = Cesium.Cartographic.toCartesian(
      cartographicDesination
    );
    // Flies to the destination on release of the mouse button
    viewer.camera.flyTo({
      destination: ObjDetectXYZ,
      duration: 2,
      heading: 0,
    });
  }
  const handler2 = new Cesium.ScreenSpaceEventHandler(scene.canvas);
  let handlermove2 = handler.setInputAction(function (movement) {
    scene.camera.cancelFlight();
  }, Cesium.ScreenSpaceEventType.LEFT_DOWN);
}

viewer.camera.flyTo({
  destination: Cesium.Cartesian3.fromDegrees(
    -77.2975,
    18.1096,
    maximumzoomHeight
  ),
  easingFunction: Cesium.EasingFunction.QUADRATIC_IN_OUT,
  duration: 10,
  heading: 0,
});

console.log("© Copyright 2022");
