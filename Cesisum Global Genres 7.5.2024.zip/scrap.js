<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sample Page</title>
    <style>
        element.style {
            position: absolute;
            left: 0px;
            top: 0px;
            margin: 0px;
            border: none;
            padding: 0px;
            overflow: visible;
            white-space: pre;
            letter-spacing: 0px;
            display: block;
            visibility: inherit;
            width: 7px;
            transform-origin: 50% 9px;
            transform: matrix(0.999968, 0, 0.00804019, 0.999968, -4.5, -0.385175);
            pointer-events: auto;
        }
        * {
            -moz-box-sizing: border-box;
            box-sizing: border-box;
        }
        .styled-text {
            color: rgb(255, 255, 255) !important;
            font-size: 11.7544px;
            font-family: "Britannic Bold";
        }
    </style>
</head>
<body style="background-color: black;">
    <div class="styled-text">
        This is a sample text with the specified styles applied.
    </div>
</body>
</html>