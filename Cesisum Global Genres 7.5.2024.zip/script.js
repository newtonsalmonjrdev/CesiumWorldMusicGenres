Cesium.Ion.defaultAccessToken =
  "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJqdGkiOiJjZTA0MTg3NS05MDI3LTRkODgtOWY4MC0wN2FhZmI5MmIwNDciLCJpZCI6MTA1OTM2LCJpYXQiOjE2NjczMzc5NjV9.XYrEYpTnMof8gTJYhXaQmIu3Pj2CAcnvE2fB0DxYcVU";

const { BoundingSphere, BoundingSphereState, Cartesian3, Color, Viewer } =
  window.Cesium;
//Imagery Provider
const imageryProvider = new Cesium.ArcGisMapServerImageryProvider({
  // url: "https://services.arcgisonline  .com/ArcGIS/rest/services/World_Imagery/MapServer",
  url: "https://services.arcgisonline.com/arcgis/rest/services/NatGeo_World_Map/MapServer",
});

const viewer = new Cesium.Viewer("cesiumContainer", {
  selectionIndicator: false,
  infoBox: false,
  imageryProvider: imageryProvider,
  requestRenderMode: true,
  maximumRenderTimeChange: Infinity,
});

const scene = viewer.scene;
const camera = viewer.camera.position;
let camPos = viewer.camera.positionCartographic;
let latitude;
let longitude;
let windowPosition = "";
let entities = "";
let geoJSONDataList = "";
let objectDetected = false;
let ObjDetected_Long;
let ObjDetected_Lat;
const cssCircleOverlayX = viewer.container.clientWidth;
const cssCircleOverlayY = viewer.container.clientHeight;
const minimumzoomHeight = 2500000;
const maximumzoomHeight = 7000000;
let promise1 = [];

// window.onerror = stoperror;

//Disabling timeline and animation widgets
viewer.animation.container.style.visibility = "hidden";
viewer.timeline.container.style.visibility = "hidden";

viewer.forceResize();

circleX = viewer.container.clientWidth;
circleY = viewer.container.clientHeight;

//Circle animation when centering on point
const domspinningcircle = document.getElementById("spinningcircle");
const domcesiumContainer = document.getElementById("cesiumContainer");

// Function to make the container transparent
// Functions to add CSS classes for transparency and disappearance
const makeTransparent = () => domspinningcircle.classList.add("transparent");
const makedisappear = () => domspinningcircle.classList.add("nospincircle");

// Instantiate Cesium event handler for screen space events
var handlerScreenCircle = new Cesium.ScreenSpaceEventHandler(
  viewer.scene.canvas
);

let scrollTimeout; // Variable to store the timeout ID

// Function to reset the scroll timeout
const resetScrollTimeout = () => {
  clearTimeout(scrollTimeout); // Clear any existing timeout

  // Set a new timeout to make the element transparent after 2 seconds
  scrollTimeout = setTimeout(() => {
    makeTransparent();

    // Set another timeout to make the element disappear 2 seconds after it becomes transparent
    setTimeout(makedisappear, 3000);
  }, 2000);
};

// Handle mousedown event (LEFT_DOWN)
handlerScreenCircle.setInputAction(() => {
  domspinningcircle.classList.remove("transparent"); // Make container opaque
  domspinningcircle.classList.remove("nospincircle"); // Make container visible
  clearTimeout(scrollTimeout); // Clear any existing timeouts to prevent premature disappearance
}, Cesium.ScreenSpaceEventType.LEFT_DOWN);

// Handle mouseup event (LEFT_UP)
handlerScreenCircle.setInputAction(() => {
  resetScrollTimeout(); // Reset the scroll timeout on mouse up
}, Cesium.ScreenSpaceEventType.LEFT_UP);

// Initial call to make the element transparent after 4 seconds
setTimeout(() => {
  makeTransparent();

  // Set another timeout to make the element disappear 2 seconds after it becomes transparent
  setTimeout(makedisappear, 2000);
}, 4000);

// Listen for scroll events and reset the scroll timeout
window.addEventListener("scroll", resetScrollTimeout);

// const makeTransparent = () => domspinningcircle.classList.add("transparent");
// const makedisappear = () => domspinningcircle.classList.add("nospincircle");

// var handlerScreenCircle = new Cesium.ScreenSpaceEventHandler(
//   viewer.scene.canvas
// );

// // Handle mousedown event
// handlerScreenCircle.setInputAction(function () {
//   domspinningcircle.classList.remove("transparent"); // Make container opaque when dragging starts
//   domspinningcircle.classList.remove("nospincircle");
// }, Cesium.ScreenSpaceEventType.LEFT_DOWN); // LEFT_DOWN is equivalent to mousedown

// // Handle mouseup event
// handlerScreenCircle.setInputAction(function () {
//   // domspinningcircle.classList.add("transparent"); // Make container transparent when mouse is released
//   setTimeout(makeTransparent, 2000); // Adjust the time as needed
//   setTimeout(makedisappear, 4000);
// }, Cesium.ScreenSpaceEventType.LEFT_UP); // LEFT_UP is equivalent to mouseup

// setTimeout(makeTransparent, 4000); // Adjust the time as needed

// Clicking on Explore button
let isFirstClick = true;
// // function exploreButtonClick()
// document.querySelectorAll(".explorecontent-style").forEach(function (element) {
//   element.style.display = "contents";
// });

// document.getElementById("exploreButton").addEventListener("click", function () {
//   const alreadyActive = this.classList.contains("active");

//   document.querySelectorAll(".button-toggle").forEach(function (element) {
//     element.classList.remove("active");
//   });
//   document.querySelectorAll(".content").forEach(function (element) {
//     element.classList.remove("active");
//   });

//   // document.getElementById("exploreContent").classList.add("active");

//   if (alreadyActive) {
//     // If 'searchButton' is not already active, add 'active' class to it and toggle all targets

//     this.classList.remove("active");
//     document
//       .querySelectorAll(".explorecontent-style")
//       .forEach(function (element) {
//         element.style.display = "none";
//       });
//     // document.getElementById("exploreContent").classList.remove("active");
//   } else if (isFirstClick) {
//     document
//       .querySelectorAll(".explorecontent-style")
//       .forEach(function (element) {
//         element.style.display = "none";
//         isFirstClick = false;
//       });
//   } else {
//     // Remove 'active' class from 'exploreButton'
//     this.classList.add("active");
//     document
//       .querySelectorAll(".explorecontent-style")
//       .forEach(function (element) {
//         element.style.display = "contents";
//       });
//     document.getElementById("exploreContent").classList.add("active");
//     // this.classList.remove("active");
//     // document.getElementById("exploreContent").classList.remove("active");
//   }
// });

// exploreButtonClick();

//Clicking on Favorites tab button
// function favoritiesButtonClick() {
//   document
//     .getElementById("favoritesButton")
//     .addEventListener("click", function () {
//       const alreadyActive = this.classList.contains("active");

//       document.querySelectorAll(".button-toggle").forEach(function (element) {
//         element.classList.remove("active");
//       });
//       document.querySelectorAll(".content").forEach(function (element) {
//         element.classList.remove("active");
//       });

//       this.classList.remove("active");
//       document
//         .querySelectorAll(".explorecontent-style")
//         .forEach(function (element) {
//           element.style.display = "none";
//         });
//       if (alreadyActive) {
//         // Remove 'active' class from 'searchButton'
//         this.classList.remove("active");
//         document.getElementById("favoritesContent").classList.remove("active");
//       } else {
//         // If 'searchButton' is not already active, add 'active' class to it and toggle all targets
//         this.classList.add("active");
//         document.getElementById("favoritesContent").classList.add("active");
//       }
//     });
// }

// favoritiesButtonClick();

//Clicking on Playlist button
// function playlistButtonClick() {
//   document
//     .getElementById("playlistsButton")
//     .addEventListener("click", function () {
//       const alreadyActive = this.classList.contains("active");

//       document.querySelectorAll(".button-toggle").forEach(function (element) {
//         element.classList.remove("active");
//       });
//       document.querySelectorAll(".content").forEach(function (element) {
//         element.classList.remove("active");
//       });

//       this.classList.remove("active");
//       document
//         .querySelectorAll(".explorecontent-style")
//         .forEach(function (element) {
//           element.style.display = "none";
//         });

//       if (alreadyActive) {
//         // Remove 'active' class from 'playlistButton'
//         this.classList.remove("active");
//         document.getElementById("playlistsContent").classList.remove("active");
//       } else {
//         // If 'searchButton' is not already active, add 'active' class to it and toggle all targets
//         this.classList.add("active");
//         document.getElementById("playlistsContent").classList.add("active");
//       }
//     });
// }
// playlistButtonClick();

// //Clicking on Search button

// function searchButtonClick() {
//   document
//     .getElementById("searchButton")
//     .addEventListener("click", function () {
//       const alreadyActive = this.classList.contains("active");

//       // Remove 'active' class from all elements with class 'button-toggle'
//       document.querySelectorAll(".button-toggle").forEach(function (element) {
//         element.classList.remove("active");
//       });

//       // Remove 'active' class from all elements with class 'content'
//       document.querySelectorAll(".content").forEach(function (element) {
//         element.classList.remove("active");
//       });

//       // Hide all elements with class 'explorecontent-style'
//       document
//         .querySelectorAll(".explorecontent-style")
//         .forEach(function (element) {
//           element.style.display = "none";
//         });

//       if (alreadyActive) {
//         // If the button is already active, remove 'active' class from it and hide the search bar
//         this.classList.remove("active");
//         document.getElementById("searchContent").classList.remove("active");
//         document.getElementById("searchbarid").style.display = "none";
//       } else {
//         // If the button is not already active, add 'active' class to it and show the search bar
//         this.classList.add("active");
//         document.getElementById("searchContent").classList.add("active");
//         document.getElementById("searchbarid").style.display = "block";
//       }
//     });
// }

// searchButtonClick();
// function searchButtonClick() {
//   document
//     .getElementById("searchButton")
//     .addEventListener("click", function () {
//       const alreadyActive = this.classList.contains("active");

//       document.querySelectorAll(".button-toggle").forEach(function (element) {
//         element.classList.remove("active");
//       });
//       document.querySelectorAll(".content").forEach(function (element) {
//         element.classList.remove("active");
//       });

//       this.classList.remove("active");
//       document
//         .querySelectorAll(".explorecontent-style")
//         .forEach(function (element) {
//           element.style.display = "none";
//         });

//       //add the Search controls
//       this.classList.add("active");
//       // document.getElementById("searchbarid").classList.add("active");

//       if (alreadyActive) {
//         // Remove 'active' class from 'searchButton'
//         this.classList.remove("active");
//         document.getElementById("searchContent").classList.remove("active");
//         document.getElementById("searchbarid").classList.remove("active");
//       } else {
//         // If 'searchButton' is not already active, add 'active' class to it and toggle all targets
//         this.classList.add("active");
//         document.getElementById("searchContent").classList.add("active");
//         document.getElementById("searchbarid").classList.add("active");
//       }
//     });
// }

// searchButtonClick();

//Clicking on Settings button
// function settingsButtonClick() {
//   document
//     .getElementById("settingsButton")
//     .addEventListener("click", function () {
//       const alreadyActive = this.classList.contains("active");

//       document.querySelectorAll(".button-toggle").forEach(function (element) {
//         element.classList.remove("active");
//       });
//       document.querySelectorAll(".content").forEach(function (element) {
//         element.classList.remove("active");
//       });

//       this.classList.remove("active");
//       document
//         .querySelectorAll(".explorecontent-style")
//         .forEach(function (element) {
//           element.style.display = "none";
//         });

//       if (alreadyActive) {
//         // Remove 'active' class from 'searchButton'
//         this.classList.remove("active");
//         document.getElementById("settingsContent").classList.remove("active");
//       } else {
//         // If 'searchButton' is not already active, add 'active' class to it and toggle all targets
//         this.classList.add("active");
//         document.getElementById("settingsContent").classList.add("active");
//       }
//     });
// }

// settingsButtonClick();

// var centerCircleElement = document.getElementById("centercircle");

// spinningcircle.style.position = "absolute";
// spinningcircle.style.left = "50%";
// spinningcircle.style.top = "50%";
// spinningcircle.style.transform = "translate(-50%, -50%)";

//Centering the HTML circle around the point position
// document.getElementById("centercircle").style.left = `${
//   cssCircleOverlayX - 65
// }px`;
// document.getElementById("centercircle").style.top = `${
//   cssCircleOverlayY - 65
// }px`;

//Setting the minimum and maximum zoom in level
viewer.scene.screenSpaceCameraController.minimumZoomDistance =
  minimumzoomHeight;
viewer.scene.screenSpaceCameraController.maximumZoomDistance =
  maximumzoomHeight;

//Loading Screen
const wait = (delay = 0) =>
  new Promise((resolve) => setTimeout(resolve, delay));

const setVisible = (elementOrSelector, visible) => {
  // Determine the element
  const element =
    typeof elementOrSelector === "string"
      ? document.querySelector(elementOrSelector)
      : elementOrSelector;

  // Check if the element exists before setting its style
  if (element) {
    element.style.display = visible ? "block" : "none";
  }
};

setVisible(".page", false);
setVisible("#loading", true);

document.addEventListener("DOMContentLoaded", () =>
  wait(3000).then(() => {
    setVisible(".page", true);
    setVisible("#loading", false);
    setVisible(".datadisplay-inner", true);
  })
);

//Read quote lines
const url =
  "https://raw.githubusercontent.com/newtonsalmonjrdev/CesiumWorldMusicGenres/main/musicQuotes.json";
function getFromAPI(url, callback) {
  let obj;
  fetch(url)
    .then((res) => res.json())
    .then((data) => (obj = data))
    .then(() => callback(obj));
}
getFromAPI(url, generateQuotes);

function randomNumber(min, max) {
  return Math.floor(Math.random() * (max - min) + min);
}

async function generateQuotes(quotesObj) {
  const quoteNum = randomNumber(0, 42);
  const quoteDOM = quotesObj[quoteNum].quotes;
  const quoteDOMName = quotesObj[quoteNum].quoteName;

  // document.getElementById("quote").innerHTML = quoteDOM;
  // document.getElementById("quoteauthor").innerHTML = "~ " + quoteDOMName;
  // document.getElementById("quoteauthor").style.color = "darkblue";
}
// generateQuotes();

//Time stamp based on location
// Replace 'America/New_York' with the desired timezone
// const tzdData = geoJSONDataList.values[i - 1].properties.TZD;

// // Get the current time in the specified timezone
// const currentTime = moment.tz(tzdData).format("HH:mm");
// console.log(currentTime);

//Loading geoJSON files
function loadJSONPointsPolys() {
  const pointsJSON =
    "https://raw.githubusercontent.com/newtonsalmonjrdev/CesiumWorldMusicGenres/main/Sheet1_Layerexport_PointsP_9.geojson";
  promise1 = Cesium.GeoJsonDataSource.load(pointsJSON);

  promise1.then(function (dataSource1) {
    //Adding Polygon Points, 10 Miles Diameter
    entities = dataSource1.entities.values;
    geoJSONDataList = dataSource1.entities;
    viewer.dataSources.add(
      Cesium.GeoJsonDataSource.load(pointsJSON, {
        stroke: Cesium.Color.fromCssColorString("white"),
        fill: Cesium.Color.fromCssColorString("white").withAlpha(1),
        strokeWidth: 1,
      })
    );

    //Adding Polygons- to be converted into buffer ellipses, 100 Miles Diameter
    const polygonJSON =
      "https://raw.githubusercontent.com/newtonsalmonjrdev/CesiumWorldMusicGenres/main/buffer_1009_json.geojson";
    const promise2 = Cesium.GeoJsonDataSource.load(polygonJSON);
    promise2.then(function (dataSource2) {
      viewer.dataSources.add(
        Cesium.GeoJsonDataSource.load(polygonJSON, {
          stroke: Cesium.Color.TRANSPARENT,
          fill: Cesium.Color.TRANSPARENT.withAlpha(0.01),
          strokeWidth: 3,
        })
      );
    });
  });
}

//Getting the Cartesian point of the center window position
function getPosition() {
  windowPosition = new Cesium.Cartesian2(
    viewer.container.clientWidth / 2,
    viewer.container.clientHeight / 2
  );

  // circleY = viewer.container.clientHeight;

  let pickRay = viewer.scene.camera.getPickRay(windowPosition);
  let pickPosition = viewer.scene.globe.pick(pickRay, viewer.scene);
  if (!pickPosition) {
    console.log("The pick position is not on the globe.");
    return; // Continue the outer flow, effectively doing nothing further if pickPosition is undefined
  } else {
    let pickPositionCartographic =
      viewer.scene.globe.ellipsoid.cartesianToCartographic(pickPosition);
    longitude = pickPositionCartographic.longitude * (180 / Math.PI);
    latitude = pickPositionCartographic.latitude * (180 / Math.PI);
  }

  // If pickPosition is valid, execute the next line of code

  // console.log(pickPosition);
  // let pickPositionCartographic =
  //   viewer.scene.globe.ellipsoid.cartesianToCartographic(pickPosition);
}

// This is what's retrieving the cursor's current postion
const handler = new Cesium.ScreenSpaceEventHandler(scene.canvas);
let handlermove = handler.setInputAction(function (movement) {
  getPosition();
}, Cesium.ScreenSpaceEventType.MOUSE_MOVE);

function stoperror() {
  return true;
}
stoperror();
let switch1 = "0";
// This is retrieving the geoJSON info
function getGeoJSONProps() {
  let handler1 = new Cesium.ScreenSpaceEventHandler(scene.canvas);
  handler1.setInputAction(function () {
    const idlist = [...Array(72).keys()];
    pickedObjects = scene.pick(windowPosition);
    if (Cesium.defined(pickedObjects)) {
      for (let i = 0; i < idlist.length; ++i) {
        if (pickedObjects.id.id === i) {
          // insert new radius code here
          // Function to check if a point is within a specified radius from another point
          function isPointWithinRadius(center, target, radius) {
            // Convert the positions to Cartesian3
            var centerCartesian = Cesium.Cartesian3.fromDegrees(
              center.longitude,
              center.latitude,
              center.height
            );
            var targetCartesian = Cesium.Cartesian3.fromDegrees(
              target.longitude,
              target.latitude,
              target.height
            );

            // Calculate the distance between the points
            var distance = Cesium.Cartesian3.distance(
              centerCartesian,
              targetCartesian
            );

            // Check if the distance is within the specified radius
            return distance <= radius;
          }

          let cameraHeight = viewer.camera._positionCartographic.height;
          // Center point (fixed)
          var centerPoint = {
            longitude: longitude,
            latitude: latitude,
            height: cameraHeight, // Optional: height in meters
          };

          // Add the center point to the viewer
          viewer.entities.add({
            position: Cesium.Cartesian3.fromDegrees(
              centerPoint.longitude,
              centerPoint.latitude,
              centerPoint.height
            ),
            point: {
              pixelSize: 10,
              color: Cesium.Color.RED,
            },
          });

          // Function to update the radius and check if the center of the screen is within the radius
          function updateRadius() {
            // Get the camera position
            var cameraPosition = viewer.camera._positionCartographic;
            var radius = cameraPosition.height / 27;
            var centerOfScreen = viewer.camera.pickEllipsoid(
              new Cesium.Cartesian2(
                viewer.container.clientWidth / 2,
                viewer.container.clientHeight / 2
              ),
              scene.globe.ellipsoid
            );

            // Check if the center of the screen is valid
            if (!centerOfScreen) {
              console.log("Center of screen is not on the ellipsoid.");
              return;
            }

            var centerOfScreenCartographic =
              Cesium.Cartographic.fromCartesian(centerOfScreen);

            var targetPoint = {
              longitude: Cesium.Math.toDegrees(
                centerOfScreenCartographic.longitude
              ),
              latitude: Cesium.Math.toDegrees(
                centerOfScreenCartographic.latitude
              ),
              height: centerOfScreenCartographic.height,
            };

            // Check if the center of the screen is within the radius
            var isWithinRadius = isPointWithinRadius(
              centerPoint,
              targetPoint,
              radius
            );
            console.log(
              "Is the center of the screen within the radius? " + isWithinRadius
            );

            // Visualize the radius as an ellipse
            viewer.entities.removeAll();
            viewer.entities.add({
              position: Cesium.Cartesian3.fromDegrees(
                centerPoint.longitude,
                centerPoint.latitude,
                centerPoint.height
              ),
              point: {
                pixelSize: 10,
                color: Cesium.Color.RED,
              },
            });
            viewer.entities.add({
              position: Cesium.Cartesian3.fromDegrees(
                centerPoint.longitude,
                centerPoint.latitude,
                centerPoint.height
              ),
              ellipse: {
                semiMinorAxis: radius,
                semiMajorAxis: radius,
                material: new Cesium.ColorMaterialProperty(
                  Cesium.Color.YELLOW.withAlpha(0.5)
                ),
              },
            });
          }

          // Add event listener for camera changes (including zoom)
          viewer.camera.changed.addEventListener(updateRadius);

          // Initial radius update
          updateRadius();

          // Adjust view to see the center point
          viewer.zoomTo(viewer.entities);

          //Getting Lat and Long data for fly-to-center function
          objectDetected = true;
          ObjDetected_Long = geoJSONDataList.values[i - 1].properties.Longitude;
          ObjDetected_Lat = geoJSONDataList.values[i - 1].properties.Latitude;

          //Removing Welcome div
          document.getElementById("welcomeid").innerHTML = "";
          if (typeof getWelcomeDiv != "undefined" && getWelcomeDiv != null) {
            document.getElementById("welcomedivID").remove();
          }

          //Remove generic info blurb
          const genericInfoBlurb = document.getElementById("genericinfo-id");
          genericInfoBlurb.innerHTML = "";

          //Pushing data into the DOM

          //Artist Name
          if (geoJSONDataList.values[i - 1].properties.Artist_Name != "NA") {
            document.getElementById("artistname").innerHTML =
              geoJSONDataList.values[i - 1].properties.Artist_Name;
            document.getElementById("artistname").style.color = "white";
          } else {
            document.getElementById("artistname").innerHTML = "";
          }
          //Band Group
          if (
            geoJSONDataList.values[i - 1].properties.Band_Group__if_any_ != "NA"
          ) {
            document.getElementById("bandgroup").innerHTML =
              geoJSONDataList.values[i - 1].properties.Band_Group__if_any_;
            document.getElementById("bandgroup").style.display = "none";
          } else {
            document.getElementById("bandgroup").innerHTML = "";
          }
          //Birth Year
          // if (geoJSONDataList.values[i - 1].properties.Birth_Year != "NA") {
          //   document.getElementById("birthyear").innerHTML =
          //     geoJSONDataList.values[i - 1].properties.Birth_Year + "&nbsp —";
          //   document.getElementById("birthyear").style.display = "none";
          // } else {
          //   document.getElementById("birthyear").innerHTML = "";
          // }

          //Death Year
          // if (geoJSONDataList.values[i - 1].properties.Death_Year != "NA") {
          //   document.getElementById("deathyear").innerHTML =
          //     geoJSONDataList.values[i - 1].properties.Death_Year;
          //   document.getElementById("deathyear").style.display = "none";
          // } else {
          //   document.getElementById("deathyear").innerHTML = "Present";
          // }

          // Country of Birth
          // if (
          //   geoJSONDataList.values[i - 1].properties.Country_of_Birth != "NA"
          // ) {
          //   document.getElementById("birthcountry").innerHTML =
          //     geoJSONDataList.values[i - 1].properties.Country_of_Birth;
          //   document.getElementById("birthcountry").style.color = "gold";
          // } else {
          //   document.getElementById("birthcountry").innerHTML = "";
          // }

          //Birth and Death Years
          let birthYear = geoJSONDataList.values[i - 1].properties.Birth_Year;
          let deathYear = geoJSONDataList.values[i - 1].properties.Death_Year;

          // Create combined year string
          let combinedYears = "";

          if (birthYear != "NA") {
            combinedYears += birthYear;
          } else {
            combinedYears += ""; // or some default value if needed
          }

          combinedYears += " — ";

          if (deathYear != "NA") {
            combinedYears += deathYear;
          } else {
            combinedYears += "Present";
          }

          // Update HTML element with the combined years
          document.getElementById("combined-years").innerHTML = combinedYears;

          //Genres
          let primaryGenre =
            geoJSONDataList.values[i - 1].properties.Primary_Genre;
          let secondaryGenre =
            geoJSONDataList.values[i - 1].properties.Secondary_Genre;
          let tertiaryGenre =
            geoJSONDataList.values[i - 1].properties.Tertiary_Genre;

          // Create combined genre string
          let combinedGenres = "";

          if (primaryGenre != "NA") {
            combinedGenres += primaryGenre + " ";
          }

          if (secondaryGenre != "NA") {
            if (combinedGenres !== "") {
              combinedGenres += " | ";
            }
            combinedGenres += secondaryGenre;
          }

          if (tertiaryGenre != "NA") {
            if (combinedGenres !== "") {
              combinedGenres += " | ";
            }
            combinedGenres += tertiaryGenre;
          }

          // Update HTML element with the combined genres
          document.getElementById("combined-genres").innerHTML = combinedGenres;

          // Primary Genre
          // if (geoJSONDataList.values[i - 1].properties.Primary_Genre != "NA") {
          //   document.getElementById("primarygen").innerHTML =
          //     geoJSONDataList.values[i - 1].properties.Primary_Genre + "&ensp;";
          // } else {
          //   document.getElementById("primarygen").innerHTML = "";
          // }

          // Secondary Genre
          // if (
          //   geoJSONDataList.values[i - 1].properties.Secondary_Genre != "NA"
          // ) {
          //   document.getElementById("secondgen").innerHTML =
          //     geoJSONDataList.values[i - 1].properties.Secondary_Genre +
          //     "&ensp;";
          //   document.getElementById("secondgen").style.display = "none";
          // } else {
          //   document.getElementById("secondgen").innerHTML = "";
          // }

          //Tertiary Genre
          // if (geoJSONDataList.values[i - 1].properties.Tertiary_Genre != "NA") {
          //   document.getElementById("tertgen").innerHTML =
          //     geoJSONDataList.values[i - 1].properties.Tertiary_Genre;
          //   document.getElementById("tertgen").style.display = "none";
          // } else {
          //   document.getElementById("tertgen").innerHTML = "";
          // }

          //Wikipedia
          if (geoJSONDataList.values[i - 1].properties.Wikipedia_Link != "NA") {
            let wikiurl =
              geoJSONDataList.values[i - 1].properties.Wikipedia_Link;
            document.getElementById("wikilink").setAttribute("href", wikiurl);
            // document.getElementById("wikilink").innerHTML = "Wikipedia";
            document.getElementById("wikilink").style.display = "none";
          } else {
            document.getElementById("wikilink").innerHTML = "";
          }

          //Youtube
          if (geoJSONDataList.values[i - 1].properties.Youtube != "NA") {
            let youtubeurl = geoJSONDataList.values[i - 1].properties.Youtube;
            document
              .getElementById("youtubelink")
              .setAttribute("href", youtubeurl);
            // document.getElementById("youtubelink").innerHTML = "Youtube";
            document.getElementById("youtubelink").style.display = "none";
          } else {
            document.getElementById("youtubelink").innerHTML = "";
          }

          //City of Birth
          if (geoJSONDataList.values[i - 1].properties.City_of_Birth != "NA") {
            document.getElementById("birthcity").innerHTML =
              geoJSONDataList.values[i - 1].properties.City_of_Birth +
              ", " +
              geoJSONDataList.values[i - 1].properties.Country_of_Birth;
            geoJSONDataList.values[i - 1].properties.Country_of_Birth;
            document.getElementById("birthcity").style.color = "white";
          } else {
            document.getElementById("birthcity").innerHTML = "";
          }

          //Alias
          if (geoJSONDataList.values[i - 1].properties.Alias_Name != "NA") {
            document.getElementById("alias").innerHTML =
              "A.K.A. " + geoJSONDataList.values[i - 1].properties.Alias_Name;
            document.getElementById("alias").style.display = "none";
          } else {
            document.getElementById("alias").innerHTML = "";
            document.getElementById("alias").style.color = "purple";
          }

          if (geoJSONDataList.values[i - 1].properties.Spotify_Code != "NA") {
            // Spotify Playlist
            // document.getElementById("spotifyiframe").src =
            //   geoJSONDataList.values[i - 1].properties.SpotifySrc;

            const strSpotify =
              geoJSONDataList.values[i - 1].properties.SpotifySrc._value;
            const parts = strSpotify.split("/");

            // The artist ID should be the part right before the query parameters, assuming the URL structure remains constant
            const artistIDWithParams = parts[parts.length - 1];

            // Splitting by '?' to remove any query parameters
            const artistID = artistIDWithParams.split("?")[0];
            const artistURI = `spotify:artist:${artistID}`;

            window.artistURI = artistURI;

            const elementToRemove = document.getElementById("embed-outer");

            elementToRemove.remove();

            const parentElement = document.getElementById("databoxid");

            const newSpotifyOuterDiv = document.createElement("div");
            const newSpotifyInnerDiv = document.createElement("div");

            // Set IDs
            newSpotifyOuterDiv.id = "embed-outer";
            newSpotifyInnerDiv.id = "embed-iframe";

            // Append the inner div to the outer div
            newSpotifyOuterDiv.appendChild(newSpotifyInnerDiv);

            // Append the outer div to the parent element
            parentElement.appendChild(newSpotifyOuterDiv);

            // Logging

            window.onSpotifyIframeApiReady = (IFrameAPI) => {
              // const embedIframe = document.getElementById("embed-iframe");
              const options = {
                width: "100%",
                height: "160",
                uri: artistURI, // Use artistURI that you've already prepared
              };

              IFrameAPI.createController(
                newSpotifyInnerDiv,
                options,
                (EmbedController) => {
                  // Immediately load the artist URI without waiting for a mouseup event
                  EmbedController.loadUri(artistURI);
                  EmbedController.play();
                }
              );
            };

            const moreContentVar = document.getElementById("moreContentdiv");
            moreContentVar.classList.add("active");

            // //See More Button Visibility
            const seeMoreVar = document.getElementById("seeMoreBtn");
            if (
              seeMoreVar.style.display === "block" ||
              seeMoreVar.style.display === ""
            ) {
              seeMoreVar.style.display = "block";
              seeMoreVar.textContent = "See more";
            } else {
              seeMoreVar.style.display = "none";
              seeMoreVar.textContent = "See less";
            }
          } else {
            document.getElementById("spotifyiframe").src = "";
          }
        } else {
          continue;
        }
      }
      flyToOnClick();
    }
  }, Cesium.ScreenSpaceEventType.LEFT_UP);
}

function toggleContent(buttonId, contentId, specialHandling = null) {
  document.getElementById(buttonId).addEventListener("click", function () {
    const isActive = this.classList.contains("active");

    // Remove 'active' class from all elements with class 'button-toggle'
    document.querySelectorAll(".button-toggle").forEach(function (element) {
      element.classList.remove("active");
    });

    // Remove 'active' class from all elements with class 'content'
    document.querySelectorAll(".content").forEach(function (element) {
      element.classList.remove("active");
    });

    // Hide all elements with class 'explorecontent-style'
    // document
    //   .querySelectorAll(".explorecontent-style")
    //   .forEach(function (element) {
    //     element.classList.add("hidden");
    //   });

    if (!isActive) {
      this.classList.add("active");
      document.getElementById(contentId).classList.add("active");
      if (specialHandling) specialHandling(true);
    } else {
      // If already active, still show the content
      this.classList.add("active");
      document.getElementById(contentId).classList.add("active");
      if (specialHandling) specialHandling(true);
    }
  });
}

function searchSpecialHandling(isActive) {
  const searchBar = document.getElementById("searchbarid");
  const suggestions = document.getElementById("suggestions");
  if (isActive) {
    searchBar.style.display = "block";
    suggestions.style.display = "block";
    document
      .getElementById("searchInput")
      .addEventListener("input", function () {
        // Example: Dynamic suggestions based on input
        const query = this.value.toLowerCase();
        suggestions.innerHTML = ""; // Clear previous suggestions
        if (query) {
          const suggestionsData = [
            "Suggestion 1",
            "Suggestion 2",
            "Suggestion 3",
          ];
          const filtered = suggestionsData.filter((item) =>
            item.toLowerCase().includes(query)
          );
          filtered.forEach((item) => {
            const div = document.createElement("div");
            div.textContent = item;
            suggestions.appendChild(div);
          });
        }
      });
  } else {
    searchBar.style.display = "none";
    suggestions.style.display = "none";
  }
}

function playlistSpecialHandling(isActive) {
  const searchBar = document.querySelector("#playlistsContent .search-bar");
  const playlistList = document.querySelector(
    "#playlistsContent .playlist-list"
  );

  if (isActive) {
    searchBar.style.display = "block";
    playlistList.style.display = "block";

    document
      .getElementById("playlistSearch")
      .addEventListener("input", function () {
        // Example: Filter playlists based on search input
        const query = this.value.toLowerCase();
        const playlists = document.querySelectorAll(
          "#playlistsContent .playlist-list ul li"
        );

        playlists.forEach((playlist) => {
          if (playlist.textContent.toLowerCase().includes(query)) {
            playlist.style.display = "";
          } else {
            playlist.style.display = "none";
          }
        });
      });
  } else {
    searchBar.style.display = "none";
    playlistList.style.display = "none";
  }
}

function settingsSpecialHandling(isActive) {
  const options = document.querySelector("#settingsContent .options");
  if (isActive) {
    options.style.display = "block";
  } else {
    options.style.display = "none";
  }
}

function exploreSpecialHandling(isActive) {
  const genericInfo = document.querySelector("#moreContentdiv .explore-info");

  if (isActive) {
    genericInfo.style.display = "block";
  } else {
    genericInfo.style.display = "none";
  }
}

// document.addEventListener("DOMContentLoaded", function () {
//   document.getElementById("exploreButton").classList.add("active");
// });

// toggleContent("exploreButton", "exploreContent", exploreSpecialHandling);
toggleContent("exploreButton", "moreContentdiv", exploreSpecialHandling);
toggleContent("playlistsButton", "playlistsContent", playlistSpecialHandling);
toggleContent("searchButton", "searchContent", searchSpecialHandling);
toggleContent("settingsButton", "settingsContent", settingsSpecialHandling);
//Showing and hiding information with 'See More' button
document.getElementById("seeMoreBtn").addEventListener("click", function () {
  const seeMoreVar = document.getElementById("seeMoreBtn");
  // const birthYearElement = document.getElementById("birthyear");
  // const deathYearElement = document.getElementById("deathyear");
  // const secondaryGenElement = document.getElementById("secondgen");
  // const tertGenElement = document.getElementById("tertgen");
  const cmbyears = document.getElementById((id = "combined-years"));
  // const cmbgenres = document.getElementById((id = "combined-genres"));
  const wikiLinkElement = document.getElementById("wikilink");
  const youtubeElement = document.getElementById("youtubelink");
  const aliasElement = document.getElementById("alias");

  if (seeMoreVar.textContent === "See less") {
    seeMoreVar.textContent = "See more";
    // birthYearElement.style.display = "none";
    // deathYearElement.style.display = "none";
    // secondaryGenElement.style.display = "none";
    // tertGenElement.style.display = "none";
    cmbyears.style.display = "none";
    // cmbgenres.style.display = "none";
    wikiLinkElement.style.display = "none";
    youtubeElement.style.display = "none";
    aliasElement.style.display = "none";
  } else if (seeMoreVar.textContent === "See more") {
    seeMoreVar.textContent = "See less";
    // birthYearElement.style.display = "block";
    // deathYearElement.style.display = "block";
    // secondaryGenElement.style.display = "block";
    // tertGenElement.style.display = "block";
    cmbyears.style.display = "block";
    // cmbgenres.style.display = "block";
    wikiLinkElement.style.display = "block";
    youtubeElement.style.display = "block";
    aliasElement.style.display = "block";
  }
});

loadJSONPointsPolys();
getGeoJSONProps();

// function getCameraHeight() {
//   var scene = viewer.scene;
//   let cameraHeight = scene.camera.positionCartographic.height;

//   return cameraHeight;
// }

// Example usage
// let radiusElevation;
function flyToOnClick() {
  let cameraHeight = viewer.camera._positionCartographic.height;
  let radiusSearch = document.getElementById("staticcircle").getAttribute("r");
  // radiusElevation = cameraHeight;
  // console.log(radiusElevation);
  // let radiusHeightratio = cameraHeight / radiusSearch;
  // // let piratio = Math.PI * 2 * cameraHeight;
  // // console.log(piratio);
  // let radiusThreshhold = (cameraHeight / radiusSearch) * 3.22;
  // let cameratimes = cameraHeight * 0.022222222223;
  // let ratiodifference = cameratimes / radiusHeightratio;
  // // console.log("cameratimes " + cameratimes);
  // // console.log("radiusThreshhold " + radiusThreshhold);
  // console.log("radiusHeightratio " + radiusHeightratio);
  // console.log("ratiodifference " + ratiodifference);
  // // Here’s an example demonstrating how to detect if a point is within a radius of another point in CesiumJS. If object is ObjDetected, retrieve the target point coordinaes to carry out this code. if the target point is within the range for the circumference at that given height, (using 2pir?)
  // // function logRadiusHeightRatio(cameraHeight) {
  // //   // Calculate the radius-height ratio
  // //   let radiusHeightRatio = cameraHeight / radiusSearch;
  // //   console.log("Radius-Height Ratio: " + radiusHeightRatio);
  // // }

  // // // Add an event listener to log the radius-height ratio as the camera height changes
  // // viewer.scene.postRender.addEventListener(function () {
  // //   let cameraHeight = viewer.camera.positionCartographic.height;
  // //   logRadiusHeightRatio(cameraHeight);
  // // });
  // // radiusHeightratio <= cameratimes
  if (objectDetected) {
    // Get the camera height
    // let cameraHeight = viewer.camera._positionCartographic.height;
    // Here position is a Cartesian3 of the camera destination
    const ObjDetectXY = Cesium.Cartesian3.fromDegrees(
      Number(ObjDetected_Long),
      Number(ObjDetected_Lat),
      1000000
    );
    let cartographicDesination = Cesium.Cartographic.fromCartesian(ObjDetectXY);

    // Override its height
    cartographicDesination.height = cameraHeight;
    // Set it back to a Cartesian3, then fly to this destination
    const ObjDetectXYZ = Cesium.Cartographic.toCartesian(
      cartographicDesination
    );
    // Flies to the destination on release of the mouse button
    viewer.camera.flyTo({
      destination: ObjDetectXYZ,
      duration: 2,
      heading: 0,
    });
  }
  const handler2 = new Cesium.ScreenSpaceEventHandler(scene.canvas);
  let handlermove2 = handler.setInputAction(function (movement) {
    scene.camera.cancelFlight();
  }, Cesium.ScreenSpaceEventType.LEFT_DOWN);
}

viewer.camera.flyTo({
  destination: Cesium.Cartesian3.fromDegrees(
    -77.2975,
    18.1096,
    maximumzoomHeight
  ),
  easingFunction: Cesium.EasingFunction.QUADRATIC_IN_OUT,
  duration: 10,
  heading: 0,
});

console.log("© Copyright 2022");

// if object is detected and current height is less than radius of the circle (according to a ratio that relates the two to each other) then fly to
